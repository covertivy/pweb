import colors

COLOR_MANAGER = colors.Colors()


def check(pages):
    print(COLOR_MANAGER.PURPLE + COLOR_MANAGER.BOLD + "- XSS check:" + COLOR_MANAGER.ENDC)
    print(COLOR_MANAGER.PURPLE + "\tnope, nothing yet")
