import colors

COLOR_MANAGER = colors.Colors()


def check(pages):
    print(COLOR_MANAGER.NAVY + COLOR_MANAGER.BOLD + "- SQL check:" + COLOR_MANAGER.ENDC)
    print(COLOR_MANAGER.NAVY + "\tnope, nothing yet")
