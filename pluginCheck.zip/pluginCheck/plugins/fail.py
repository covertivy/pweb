def lol():
    print("nope")
